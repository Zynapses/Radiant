# RADIANT v4.18.0 - Source Code Export for Gemini

Generated: 2026-01-09

## Overview

RADIANT is a multi-tenant AWS SaaS platform for AI model access and orchestration with three main components:

| Component | Location | Purpose |
|-----------|----------|---------|
| Swift Deployer App | `source/swift/` | macOS app that deploys infrastructure |
| AWS Infrastructure | `source/cdk-stacks/` | CDK stacks, Lambdas |
| Admin Dashboard | `source/admin-dashboard/` | Next.js web admin interface |

## Directory Structure

```
radiant-gemini-export/
├── docs/                      # Documentation
│   ├── RADIANT-ADMIN-GUIDE.md # Platform admin guide
│   ├── THINKTANK-ADMIN-GUIDE.md # Think Tank admin guide
│   ├── STRATEGIC-VISION-MARKETING.md # Marketing doc
│   ├── AGENTS.md              # AI agent configuration
│   ├── CHANGELOG.md           # Version history
│   └── VERSION                # Current version
│
├── source/
│   ├── cdk-stacks/           # 30 AWS CDK stacks (TypeScript)
│   ├── admin-dashboard/      # Next.js dashboard pages (TSX)
│   ├── flyte/                # Python Flyte workflows
│   ├── shared-types/         # 46 TypeScript type definitions
│   ├── swift/                # Swift macOS deployer app
│   └── lambda/               # Lambda handlers and services
│
└── README.md
```

## Key Components

### CDK Stacks (30 stacks)
- **Core**: foundation, networking, security, data, auth, monitoring, storage
- **API & App**: api-stack, admin-stack, tms-stack
- **AI/ML**: ai-stack, brain-stack, cognition-stack, formal-reasoning-stack
- **Consciousness**: consciousness-stack, cato-redis-stack, bobble-genesis-stack
- **Collaboration**: collaboration-stack, webhooks-stack, mission-control-stack
- **Multi-region**: multi-region-stack, security-monitoring-stack

### Flyte Python Workflows
- `think_tank_workflow.py` - HITL workflow with swarm parallelism
- `grimoire_tasks.py` - Self-optimizing procedural memory
- `cato_client.py` - Cato safety service HTTP bridge
- `db.py` - RLS-safe database connections
- `embeddings.py` - Vector embedding utilities

### Shared Types (46 type files)
- `cato.types.ts` - Genesis Cato safety architecture (661 lines)
- `consciousness.types.ts` - Consciousness service types (292 lines)
- `agi-brain-plan.types.ts` - Brain plan system (332 lines)
- `domain-taxonomy.types.ts` - Domain detection (320 lines)
- Plus 42 more type definition files

### Admin Dashboard (42+ pages)
- Main dashboard with system health and metrics
- Cato safety dashboard (CBF violations, escalations, recovery)
- Brain dashboard (Ghost vectors, dreams, oversight, SOFAI)
- Consciousness dashboard (self-model, curiosity, creativity, affect)
- Models, providers, billing, analytics, compliance pages

### Swift Deployer (36+ files)
- SwiftUI macOS 13.0+ application
- NavigationSplitView with Sidebar + Content + Inspector
- Services: AIAssistantService, LocalStorageManager, TimeoutService
- Modern UI with Liquid Glass design patterns

## Technology Stack

- **Swift App**: SwiftUI, macOS 13.0+, Swift 5.9+, SQLCipher
- **Infrastructure**: AWS CDK (TypeScript), Aurora PostgreSQL, Lambda, API Gateway
- **Dashboard**: Next.js 14, TypeScript, Tailwind CSS, shadcn/ui
- **AI Integration**: 106+ models (50 external + 56 self-hosted), LiteLLM
- **Workflows**: Flyte with Python 3.11

## Version

- RADIANT_VERSION: 4.18.0
- THINKTANK_VERSION: 3.2.0
